Place your image content for WhatsApp here. Name files as 1AI.png, 2AI.png, etc.
