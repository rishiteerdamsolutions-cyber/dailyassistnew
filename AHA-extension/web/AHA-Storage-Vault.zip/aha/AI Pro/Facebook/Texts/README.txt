Place your text content for Facebook here. Name files as 1AI.txt, 2AI.txt, etc. corresponding to the day of the month.
