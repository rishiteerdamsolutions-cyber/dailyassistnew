Place your image content for LinkedIn here. Name files as 1AI.png, 2AI.png, etc.
