#!/bin/bash
cd "$(dirname "$0")"
python3 content_engine_app.py
