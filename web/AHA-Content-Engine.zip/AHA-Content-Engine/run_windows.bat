@echo off
cd /d "%~dp0"
python content_engine_app.py
pause
